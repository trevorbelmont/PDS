#include <math.h>
#include <stdio.h>

// default 8x8 dimensions - apenas quando não especificado no terminal
#ifndef dimensions
#define dimensions 8
#endif
// configura a consideração global para falsa por default - pode ser alterado no terminal
#ifndef global
#define global 0
#endif

int mov[dimensions * dimensions][1 + 8] = {0};  // 1[freedom] + 8[movimentos]
int tile[dimensions][dimensions] = {0};         // output concerns
int dim;

void setup();
void updateKnightMoves();             // atualizacao global da matriz de tiles e freedom
int updateKnightMoves(int x, int y);  // atualicaao local de tiles nao visitadas. Retorna freedom do tile[x][y]
void displayChessBoard();
void displayKnightMovements();

void update() {
    setup();
    displayChessBoard();
    displayKnightMovements();
}

int updateKnightMoves(int x, int y) {  // atualiza os movimentos de uma casa [tile] específico
    int freedom = 0;
    int mvmnt = 0;

    // for e condições que determinam os 8 movimentos do cavalo
    for (int l = -2; l <= 2; l++) {
        if (l == 0) continue;
        int c = (((abs(l) + 2) % 2) + 1);

        mvmnt++;
        // todas as variações a direita -já que c é sempre positivo
        if (x + c >= 0 && x + c < dim && y + l >= 0 && y + l < dim && tile[x + c][y + l] < 0) {
            freedom++;
            mov[y * dim + x][mvmnt] = mvmnt;
        }
        mvmnt++;
        // todas avariações a esquerda, já que c é sempre positivo
        if (x - c >= 0 && x - c < dim && y + l >= 0 && y + l < dim && tile[x - c][y + l] < 0) {
            freedom++;
            mov[y * dim + x][mvmnt] = mvmnt;
        }
    }
    mov[y * dim + x][0] = freedom;
    return freedom;
}

void updateKnightMoves() {  // reseta movimentos de toda a matriz do tabuleiro - útil na iicialização
    // for que determina a matriz
    for (int x = 0; x < dim; x++) {
        for (int y = 0; y < dim; y++) {
            int freedom = 0;
            int mvmnt = 0;  // mapaeia e denomina (numera) cada movimento do cavalo neste algoritmo
            // movimentos que são opostos tem sempre somatória 9. Ou seja, mvmnt de ida + volta = 9;

            // for e condições que determinam os 8 movimentos do cavalo
            for (int l = -2; l <= 2; l++) {
                if (l == 0) continue;
                int c = (((abs(l) + 2) % 2) + 1);
                mvmnt++;
                // todas as variações a direita -já que c é sempre positivo
                if (x + c >= 0 && x + c < dim && y + l >= 0 && y + l < dim) {
                    freedom++;
                    mov[y * dim + x][mvmnt] = mvmnt;
                }
                mvmnt++;
                // todas avariações a esquerda, já que c é sempre positivo
                if (x - c >= 0 && x - c < dim && y + l >= 0 && y + l < dim) {
                    freedom++;
                    mov[y * dim + x][mvmnt] = mvmnt;
                }
            }
            mov[y * dim + x][0] = freedom;
        }
    }
}

void setup() {
    dim = dimensions;
    // duplo for que percorre a matriz
    for (int x = 0; x < dim; x++) {
        for (int y = 0; y < dim; y++) {
            tile[x][y] = -1;  // atribui -1 inicialmente a todos os tiles (output concerns)

            int i = 0;
            while (i < dim) {                // for que percorre os 8 mov[dim * dim][8] de cada title[dim][dim]
                mov[(y * dim) + x][i] = 0;  // atribui -1 para a freedom e pra os 8 mov
                i++;
            }
        }
    }
    if (global != 0) {
        for (int x = 0; x < dim; x++)
            for (int y = 0; y < dim; y++)
                updateKnightMoves(x, y);  // atualiza todos os movimentos de todos os tiles da matriz
    } else {
        updateKnightMoves();
    }
}

void displayChessBoard() {  // desenha a matriz com /step#freedom/
    printf("\n //////     STEPS AND FREEDOM     //////// \n");
    for (int i = 0; i < dim; i++) {
        for (int j = 0; j < dim; j++) {
            printf(" |%d#%d| ", tile[i][j], mov[i * dim + j][0]);
        }
        printf("\n");
    }
}

void displayKnightMovements() {  // desenha a matriz com /step#freedom/
    printf("\n ****     KNIGHT MOVES    *****\n");
    for (int i = 0; i < dim; i++) {
        for (int j = 0; j < dim; j++) {
            printf(" |");
            for (int k = 0; k < 9; k++) { //for que percorre os mvmnts (movimentos)
                printf("%d", mov[j * dim + i][k]);
            }
            printf("| ");
        }
        printf("\n");
    }
}