#include "Knight.h"

int main()
{
    update();
    return 0;
}